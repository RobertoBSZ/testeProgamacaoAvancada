// consultaController.ts

import { Request, Response } from 'express';
import { PrismaClient } from '@prisma/client';

const prisma = new PrismaClient();

class ConsultaController {
  async criarConsulta(req: Request, res: Response) {
    const { data, nomePacnte, nomeSecretaria, nomeDents } = req.body;

    try {
      const consulta = await prisma.consulta.create({
        data: {
          data,
          nomePacnte,
          nomeSecretaria,
          nomeDents,
        },
      });
      res.status(201).json(consulta);
    } catch (error) {
      console.error('Erro ao criar consulta:', error);
      res.status(500).json({ error: 'Erro ao criar consulta.' });
    }
  }

  async listarConsultas(req: Request, res: Response) {
    try {
      const consultas = await prisma.consulta.findMany();
      res.status(200).json(consultas);
    } catch (error) {
      console.error('Erro ao listar consultas:', error);
      res.status(500).json({ error: 'Erro ao listar consultas.' });
    }
  }

  async lerConsulta(req: Request, res: Response) {
    const { id } = req.params;

    try {
      const consulta = await prisma.consulta.findUnique({
        where: { id: Number(id) },
        include: {
          paciente: true,
          secretaria: true,
          agendas: true,
        },
      });

      if (!consulta) {
        return res.status(404).json({ error: 'Consulta não encontrada.' });
      }

      res.status(200).json(consulta);
    } catch (error) {
      console.error('Erro ao ler consulta:', error);
      res.status(500).json({ error: 'Erro ao ler consulta.' });
    }
  }

  async atualizarConsulta(req: Request, res: Response) {
    const { id } = req.params;
    const { data, nomePacnte, nomeSecretaria, nomeDents } = req.body;

    try {
      const consulta = await prisma.consulta.update({
        where: { id: Number(id) },
        data: {
          data,
          nomePacnte,
          nomeSecretaria,
          nomeDents,
        },
        include: {
          paciente: true,
          secretaria: true,
          agendas: true,
        },
      });

      res.status(200).json(consulta);
    } catch (error) {
      console.error('Erro ao atualizar consulta:', error);
      res.status(500).json({ error: 'Erro ao atualizar consulta.' });
    }
  }

  async deletarConsulta(req: Request, res: Response) {
    const { id } = req.params;

    try {
      await prisma.consulta.delete({
        where: { id: Number(id) },
      });

      res.status(204).end();
    } catch (error) {
      console.error('Erro ao deletar consulta:', error);
      res.status(500).json({ error: 'Erro ao deletar consulta.' });
    }
  }
}

export default new ConsultaController();
