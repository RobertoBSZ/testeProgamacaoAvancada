// pacienteController.ts

import { Request, Response } from 'express';
import { PrismaClient } from '@prisma/client';

const prisma = new PrismaClient();

class PacienteController {
  async criarPaciente(req: Request, res: Response) {
    const { nomePcnte, senha, usuario } = req.body;

    try {
      const paciente = await prisma.paciente.create({
        data: {
          nomePcnte,
          senha,
          usuario,
        },
      });
      res.status(201).json(paciente);
    } catch (error) {
      console.error('Erro ao criar paciente:', error);
      res.status(500).json({ error: 'Erro ao criar paciente.' });
    }
  }

  async listarPacientes(req: Request, res: Response) {
    try {
      const pacientes = await prisma.paciente.findMany();
      res.status(200).json(pacientes);
    } catch (error) {
      console.error('Erro ao listar pacientes:', error);
      res.status(500).json({ error: 'Erro ao listar pacientes.' });
    }
  }

  async lerPaciente(req: Request, res: Response) {
    const { id } = req.params;

    try {
      const paciente = await prisma.paciente.findUnique({
        where: { id: Number(id) },
      });

      if (!paciente) {
        return res.status(404).json({ error: 'Paciente não encontrado.' });
      }

      res.status(200).json(paciente);
    } catch (error) {
      console.error('Erro ao ler paciente:', error);
      res.status(500).json({ error: 'Erro ao ler paciente.' });
    }
  }

  async atualizarPaciente(req: Request, res: Response) {
    const { id } = req.params;
    const { nomePcnte, senha, usuario } = req.body;

    try {
      const paciente = await prisma.paciente.update({
        where: { id: Number(id) },
        data: {
          nomePcnte,
          senha,
          usuario,
        },
      });

      res.status(200).json(paciente);
    } catch (error) {
      console.error('Erro ao atualizar paciente:', error);
      res.status(500).json({ error: 'Erro ao atualizar paciente.' });
    }
  }

  async deletarPaciente(req: Request, res: Response) {
    const { id } = req.params;

    try {
      await prisma.paciente.delete({
        where: { id: Number(id) },
      });

      res.status(204).end();
    } catch (error) {
      console.error('Erro ao deletar paciente:', error);
      res.status(500).json({ error: 'Erro ao deletar paciente.' });
    }
  }
}

export default new PacienteController();
